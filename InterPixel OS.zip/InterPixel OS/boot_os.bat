@echo off
title Reboot of Interpixel OS

echo ==========================
echo   Rebooting InterPixel 1.0
echo ==========================

cd /d %~dp0

python app.py

pause
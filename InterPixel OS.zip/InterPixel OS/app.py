from flask import Flask, render_template, jsonify
import psutil

app = Flask(__name__)

@app.route("/")
def desktop():
    return render_template("desktop.html")  # your main OS UI

@app.route("/taskmanager")
def taskmanager():
    return render_template("taskmanager.html")
@app.route("/whiteboard")
def whiteboard():
    return render_template("whiteboard.html")

@app.route('/api/stats/')
def stats():
    return jsonify({
        'cpu': psutil.cpu_percent(interval=1),
        'ram': psutil.virtual_memory().percent
    })

if __name__ == '__main__':
    app.run(debug=True)